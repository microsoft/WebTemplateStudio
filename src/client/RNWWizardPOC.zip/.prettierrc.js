module.exports = {
    printWidth: 120,
    tabWidth: 2,
    trailingComma: "es5",
  };