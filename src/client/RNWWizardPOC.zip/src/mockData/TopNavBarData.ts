const topNavBarData: string[] = [
  "Name and Output",
  "Add Frameworks",
  "Add Pages",
  "Add Optional Cloud Services",
  "Summary"
];

export default topNavBarData;
