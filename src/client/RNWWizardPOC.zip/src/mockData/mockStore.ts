import { ISelected } from "../types/selected";
import { FormattedMessage } from "react-intl";
import { AppState } from "../store/combineReducers";
import { ModalType } from "../store/navigation/typeKeys";
import { ROUTES } from "../utils/constants";

export const getISelected = () => {
  const selected: ISelected = {
    title:"title1",
    internalName:"internamName1"
  };
  return selected;
};

export const getInitialState = (): AppState => {
  const initialState: AppState={
    templates: {
      backendOptions: [],
      frontendOptions: [],
      pageOptions: [],
      featureOptions: [],
      feaRNWOptions:[{
        body:"1",
        internalName:"1",
        svgUrl:"1",
        title:"1"
      }]
    },
    config:{
      detailsPage: {
        isIntlFormatted: false,
        data: {
          title: '',
          internalName: '',
          body: '',
          longDescription: '',
          position: 0,
          licenses: [],
          selected: false,
          author: '',
          svgUrl:''
        },
        originRoute:''
      },
      previewStatus: false,
      validations: {
        itemNameValidationConfig: {
          regexs: [],
          reservedNames: [],
          validateEmptyNames: true,
          validateExistingNames: true,
          validateDefaultNames: true
        },
        projectNameValidationConfig: {
          regexs: [],
          reservedNames: [],
          validateEmptyNames: true,
          validateExistingNames: true
        }
      },
      versions: {
        templatesVersion: '0.0.1',
        wizardVersion: '0.0.2'
      },
      azureProfileData: {
        subscriptions: [],
        email:''
      },
      appType: {
        title: 'Fullstack Web Application',
        internalName: 'FullStackWebApp',
        version: 'v1.0',
        licenses: ''
      }
    },
    userSelection: {
      feaRNW:[],
      frontendFramework: {
        title: '',
        internalName: '',
        version: '',
        author: ''
      },
      backendFramework: {
        title: '',
        internalName: '',
        version: '',
        author: ''
      },
      pages: [{
        author:"Microsoft",
        defaultName:"Blank",
        internalName:"wts.Page.React.Blank",
        isValidTitle:true,
        licenses:[{
          text:"Bootstrap",
          url:"https://github.com/twbs/bootstrap/blob/master/LICENSE"
        }],
        title:"Blank",
        id:"0.7087795384523403"
      }],
      outputPathObject: {
        outputPath: '/generic_output_path'
      },
      projectNameObject: {
        projectName: 'myApp',
        validation: {
          isValid: true,
          error: "" as unknown as FormattedMessage.MessageDescriptor,
          isDirty: true
        }
      },
      services: {
        cosmosDB: null,
        appService: null      
      }
    },
    navigation:{
      modals: {
        openModal: {
          modalType: null,
          modalData: null
        }
      },
      routes: {
        isVisited: {
          '/': true,
          '/SelectProjectType': false,
          '/SelectFeaRNW': false,
          '/SelectPages': false,
          '/AddPages': false,
          '/ReviewAndGenerate': false
        },
        selected: '/'
      },
      isDirty: false
    }
  };
  return initialState;
}

const loadPages = (frameWorkName: string): Array<any>=>{
  const blankPage = {
    body: 'A blank page for you to build your application from scratch.',
    internalName: 'wts.Page.' + frameWorkName + '.Blank',
    licenses: [
      {
        text: 'Bootstrap',
        url: 'https://github.com/twbs/bootstrap/blob/master/LICENSE'
      }
    ],
    longDescription: 'This is the most basic page. A blank canvas to mold into whatever you wish. The blank page leaves pretty much everything up to you.',
    selected: false,
    title: 'Blank',
    defaultName: 'Blank',
    isValidTitle: true,
    author: 'Microsoft'
  }
  const gridPage = {
    body: 'Simple image and text components which are organized into a grid.',
    internalName: 'wts.Page.' + frameWorkName + '.Grid',
    licenses: [
      {
        text: 'Bootstrap',
        url: 'https://github.com/twbs/bootstrap/blob/master/LICENSE'
      }
    ],
    longDescription: 'A page displaying simple image and text components which are organized into a grid. Grid pages are a system for creating order among elements in a website.',
    selected: false,
    title: 'Grid',
    defaultName: 'Grid',
    isValidTitle: true,
    author: 'Microsoft'
  };
  const listPage = {
    body: 'Add and remove text from an adaptive list.',
    internalName: 'wts.Page.' + frameWorkName + '.List',
    licenses: [
      {
        text: 'Bootstrap',
        url: 'https://github.com/twbs/bootstrap/blob/master/LICENSE'
      }
    ],
    longDescription: 'The list page allows you to add custom text in the form of an adaptive list. This pattern is frequently used for blog pages and messaging apps. If a database is selected from the Azure Cloud Services the list page will automatically connect to the deployed Azure database.',
    selected: false,
    title: 'List',
    defaultName: 'List',
    isValidTitle: true,
    author: 'Microsoft'
  }
  const masterPage = {
    body: 'A master pane and a details pane for content.',
    internalName: 'wts.Page.' + frameWorkName + '.MasterDetail',
    licenses: [
      {
        text: 'Bootstrap',
        url: 'https://github.com/twbs/bootstrap/blob/master/LICENSE'
      }
    ],
    longDescription: 'The master-detail page has a master pane and a details pane for content. When an item in the master list is selected, the details pane is updated. This pattern is frequently used for email and address books.',
    selected: false,
    title: 'Master Detail',
    defaultName: 'Master Detail',
    isValidTitle: true,
    author: 'Microsoft'
  };
  const pages: Array<any> = new Array<any>();
  pages.push(blankPage);
  pages.push(gridPage);
  pages.push(listPage);
  pages.push(masterPage);
  
  return pages;
}

const loadFeatures = (): Array<any> => {
  const appServiceFeature ={
    body: "Quickly build, deploy, and scale your web apps with confidence.",
    internalName: "wts.Feature.Azure.AppService",
    templateGroupIdentity: "wts.Feature.Azure.AppService",
    licenses: [],
    longDescription: "Quickly build, deploy, and scale web apps with confidence. Meet rigorous, enterprise-grade performance, security, and compliance requirements by using the fully managed platform for your operational and monitoring tasks.",
    selected: false,
    svgUrl: "",
    title: "App Service",
    defaultName: "App Service",
    isValidTitle: true,
    author: "Microsoft",
    group: "CloudHosting"
  };
  const cosmosDbFeature = {
    body: "Connect your web app to a distributed database service to access and query data using SQL or MongoDB API.",
    internalName: "wts.Feature.Azure.Cosmos",
    templateGroupIdentity: "wts.Feature.Azure.Cosmos",
    licenses: [],
    longDescription: "Azure Cosmos DB is Microsoft's proprietary globally-distributed, multi-model database service for managing data on a global scale. It offers a variety of APIs for your database including Azure Table, Core (SQL), MongoDB and Gremlin (GraphQL). Web Template Studio offers you the functionality to deploy a Cosmos DB instance from the wizard itself and select an initial location to deploy your database with the ability to scale it to multiple locations at a future time. As an added feature, deploying with the MongoDB API enables you to quickly connect the project Web Template Studio generates to your database instance.",
    selected: false,
    svgUrl: "",
    title: "Cosmos DB",
    defaultName: "Cosmos DB",
    isValidTitle: true,
    author: "Microsoft",
    group: "CloudDatabase"
  };
  return new Array<any>(
    appServiceFeature,
    cosmosDbFeature);
}

const getSubscriptionsSelector = (): Array<Subscription> => {
  const subscriptions = Array.from(Array(2).keys()).map(
    (item: number) => {
      return {
        name: `subscription ${item}`,
        isMicrosoftLearn: false
      };
    }
  );
  
  subscriptions.push({
    name: "Microsoft Learn Subscription",
    isMicrosoftLearn: true
  });

  return subscriptions;
}

export const addFrontEndFrameworksOptions = (store: AppState)=>{
  store.templates.frontendOptions = [
    {
      author: 'Facebook',
      body: 'JavaScript framework',
      internalName: 'Blank',
      licenses: ['[React](https://github.com/facebook/react/blob/master/LICENSE)  \n[Create React App](https://github.com/facebook/create-react-app/blob/master/LICENSE)'],
      longDescription: 'React is a component-based open source JavaScript library for building interfaces for single page applications. It is used for handling view layer for web and mobile apps. React allows you to design simple views for each state in your application, and React will efficiently update and render just the right components when your data changes.  \r\n\r\n  \r\nMore information about React can be found [here](https://reactjs.org).\r\n',
      position: 1,
      selected: false,
      svgUrl: '',
      title: 'Blank',
      version: '16.8.4',
      latestVersion: "0.0.1",
      latestVersionLoaded: true
    },
    {
      author: 'Google',
      body: 'JavaScript framework',
      internalName: 'NavView',
      licenses: ['[Angular](https://github.com/angular/angular/blob/master/LICENSE)  \n[Angular CLI](https://github.com/angular/angular-cli/blob/master/LICENSE)'],
      longDescription: 'Angular is a platform that makes it easy to build applications with the web. Angular combines declarative templates, dependency injection, end to end tooling, and integrated best practices to solve development challenges. Angular empowers developers to build applications that live on the web, mobile, or the desktop.\r\n\r\nMore information about Angular can be found [here](https://angular.io).\r\n',
      position: 1,
      selected: false,
      svgUrl: '',
      title: 'NavView',
      version: '7.2.0',
      latestVersion: "0.0.1",
      latestVersionLoaded: true
    }
  ];
  return store;
}

export const addBackEndFrameworksOptions = (store: AppState)=>{
  store.templates.backendOptions = [];
  return store;
}

export const addFeaturesOptions = (store: AppState) => {
  store.templates.featureOptions = loadFeatures();
}

export const getServicesGroups = (store: AppState) => {
  const groups = store.templates.featureOptions.map(g => g.group) as string[];
  return [...new Set(groups)];
}

export const loadMasters = (store: AppState) =>{
  store.templates.pageOptions = loadPages("React");
}

export const setSubscriptions = (store: AppState) => {
  store.config.azureProfileData.subscriptions = getSubscriptionsSelector();
}

export const setBackendFramework = (store: AppState, internalName: string) => {
  store.userSelection.backendFramework.internalName = internalName;
}

export const setFrontendFramework = (store: AppState, internalName: string) => {
  store.userSelection.backendFramework.internalName = internalName;
}

export const setOpenModal = (store: AppState, modalType: ModalType) => {
  store.navigation.modals.openModal.modalType = modalType;
}

export const setSelectedRoute = (store: AppState, seletedRoute: string) => {
  store.navigation.routes.selected = seletedRoute;
  switch (seletedRoute) 
  {
    case ROUTES.REVIEW_AND_GENERATE:
      store.navigation.routes.isVisited = {
        '/': true,
        '/SelectFrameworks': true,
        '/SelectPages': true,
        '/AddPages': true,
        '/ReviewAndGenerate': true
      }
  }
}

export const setAzureEmail = (store: AppState, email = "test@test.com") => {
  store.config.azureProfileData.email = email;
}

export const setGenerationData = (store: AppState) => {
  store.userSelection.pages = [getISelected()];
  store.userSelection.services.appService = {
    subscription: "",
    resourceGroup: "",
    location: "",
    siteName: "",
    internalName: "",
  };
  store.userSelection.services.cosmosDB = {
    subscription: "",
    resourceGroup: "",
    location: "",
    accountName: "",
    api: "",
    internalName: "",
    groupName: "",
  };
  return 3;
};