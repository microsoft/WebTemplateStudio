import * as React from "react";
import tabsDesign from "../../assets/03_tabs_design.png";
import svgStyles from "../svgStyles.module.css";
import classnames from "classnames";

interface IProps {
  style: string;
}

export default (props: IProps) => {
  return (<img src={tabsDesign} className={classnames(props.style, svgStyles.icon)}/>);
}