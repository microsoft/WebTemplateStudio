import * as React from "react";
import imgNotification from "../../assets/01_notification_on_desktop.png";
import svgStyles from "../svgStyles.module.css";
import classnames from "classnames";

interface IProps {
  style: string;
}

export default (props: IProps) => {
  return (<img src={imgNotification} className={classnames(props.style, svgStyles.icon)}/>);
}