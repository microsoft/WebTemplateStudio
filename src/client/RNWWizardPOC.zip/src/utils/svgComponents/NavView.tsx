import * as React from "react";
import { ReactComponent as NavView } from "../../assets/list.svg";
import svgStyles from "../svgStyles.module.css";
import classnames from "classnames";

interface IProps {
  style: string;
}

export default (props: IProps) => {
  return (<NavView className={classnames(props.style, svgStyles.icon)}/>);
}