import * as React from "react";
import themeSupport from "../../assets/02_theme_support.png";
import svgStyles from "../svgStyles.module.css";
import classnames from "classnames";

interface IProps {
  style: string;
}

export default (props: IProps) => {
  return (<img src={themeSupport} className={classnames(props.style, svgStyles.icon)}/>);
}