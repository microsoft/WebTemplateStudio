
import { defineMessages } from "react-intl";

const messages = defineMessages({
    learnMore: {
      id: "frameworkCard.details",
      defaultMessage: "Learn more"
    }
  });

export default messages;