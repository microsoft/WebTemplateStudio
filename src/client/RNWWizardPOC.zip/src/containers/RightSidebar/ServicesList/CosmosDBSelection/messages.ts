import { defineMessages } from "react-intl";

const messages = defineMessages({
    title: {
      id: "CosmosDbSelection.title",
      defaultMessage: "CosmosDB"
    }
  });

  export default messages;