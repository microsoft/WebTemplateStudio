import { defineMessages } from "react-intl";

const messages = defineMessages({
    services: {
      id: "rightSidebar.services",
      defaultMessage: "Services"
    }
  });

  export default messages;