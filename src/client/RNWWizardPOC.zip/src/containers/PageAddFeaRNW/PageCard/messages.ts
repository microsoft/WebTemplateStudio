
import { defineMessages } from "react-intl";

const messages = defineMessages({
  Preview: {
      id: "pageCard.details",
      defaultMessage: "Preview"
    }
  });

export default messages;