export interface IVersions {
  templatesVersion: string;
  wizardVersion: string;
}
