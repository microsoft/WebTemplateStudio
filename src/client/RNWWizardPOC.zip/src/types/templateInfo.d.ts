export interface ITemplateInfo {
  name: string;
  identity: string;
}
