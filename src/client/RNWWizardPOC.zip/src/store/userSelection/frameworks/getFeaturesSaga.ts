import { takeEvery, call, put } from "redux-saga/effects";
import { select } from "redux-saga/effects";
import { AppState } from "../../combineReducers";
import { getFeatures } from "../../../utils/extensionService/extensionService";
import { USERSELECTION_TYPEKEYS } from "../typeKeys";
import { getFeaturesOptions } from "../../../utils/cliTemplatesParser";
import { setFeaturesAction } from "../../templates/features/actions";
import { setFeaRNWOptionsSuccessAction } from "../../templates/feaRNW/action";
import { IOption } from "../../../types/option";

//import { ServiceState } from "../services/combineReducers";

export function* getFeaturesSaga(vscode: any) {
  yield takeEvery(USERSELECTION_TYPEKEYS.SELECT_BACKEND_FRAMEWORK, callBack);
  yield takeEvery(USERSELECTION_TYPEKEYS.SELECT_FRONTEND_FRAMEWORK, callBack);

  function* callBack() {
    //const selectedServicesSelector = (state: AppState) => state.userSelection.services;
    const selectedFrontendSelector = (state: AppState) => state.userSelection.frontendFramework;
    const selectedBackendSelector = (state: AppState) => state.userSelection.backendFramework;

    //const selectedServices: ServiceState = yield select(selectedServicesSelector);
    const selectedFrontend = yield select(selectedFrontendSelector);
    const selectedBackend = yield select(selectedBackendSelector);

    if (selectedFrontend.internalName !== "" && selectedBackend.internalName !== "") {
      const event: any = yield call(getFeatures, vscode, selectedFrontend.internalName, selectedBackend.internalName);
      const features = getFeaturesOptions(event.data.payload.features);
      yield put(setFeaturesAction(features));

      const pp: IOption[] = [{
        defaultName:"Theme Support",
        title:"Theme Support",
        body:"Adds theming support to your application",
        svgUrl:undefined,
        internalName:"rnw.themeSupport"
      },
      {
        defaultName:"Notifications",
        title:"Notifications",
        body:"Notifications allow you to receive messages",
        svgUrl:undefined,
        internalName:"rnw.notifications"
      }];
      yield put(setFeaRNWOptionsSuccessAction(pp));
    }
  }
}
