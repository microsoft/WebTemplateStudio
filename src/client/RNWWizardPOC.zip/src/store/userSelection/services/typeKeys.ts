export enum SERVICES_TYPEKEYS {
  SAVE_APP_SERVICE = "WTS/userSelection/services/SAVE_APP_SERVICE",
  REMOVE_APP_SERVICE = "WTS/userSelection/services/REMOVE_APP_SERVICE",
  SAVE_COSMOS_DB = "WTS/userSelection/services/SAVE_COSMOS_DB",
  REMOVE_COSMOS_DB = "WTS/userSelection/services/REMOVE_COSMOS_DB",
}
