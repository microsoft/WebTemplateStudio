import WizardSelectionActionType from "../selectionActionType";
import { ISelected } from "../../../types/selected";
import { USERSELECTION_TYPEKEYS } from "../typeKeys";

const feaRNWReducer = (
  state: ISelected[] = [],
  action: WizardSelectionActionType
) => {
  switch (action.type) {
    case USERSELECTION_TYPEKEYS.SELECT_FEA_RNW:
      const newPages: ISelected[] = [...action.payload];
      return newPages;
    default:
      return state;
  }
};

export default feaRNWReducer;