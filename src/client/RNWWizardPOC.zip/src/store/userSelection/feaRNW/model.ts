import { USERSELECTION_TYPEKEYS } from "../typeKeys";
import { ISelected } from "../../../types/selected";

export interface IsetFeasRNWAction {
    type: USERSELECTION_TYPEKEYS.SELECT_FEA_RNW;
    payload: ISelected[];
  }
  
  export interface ISetFeaRNWAction {
    type: USERSELECTION_TYPEKEYS.SELECT_FEA_RNW;
    payload: ISelected;
  }

  export interface IRoutes {
    [key: string]: boolean;
  }