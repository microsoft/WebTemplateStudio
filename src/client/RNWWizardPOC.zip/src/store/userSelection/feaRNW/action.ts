import { ISelected } from "../../../types/selected";
import { ISetFeaRNWAction, IsetFeasRNWAction } from "./model";
import { USERSELECTION_TYPEKEYS } from "../typeKeys";

export const setFeasRNWAction = (pages: ISelected[]): IsetFeasRNWAction => ({
  type: USERSELECTION_TYPEKEYS.SELECT_FEA_RNW,
  payload: pages
});

export const setFeaRNWAction = (page: ISelected): ISetFeaRNWAction => ({
  type: USERSELECTION_TYPEKEYS.SELECT_FEA_RNW,
  payload: page
});