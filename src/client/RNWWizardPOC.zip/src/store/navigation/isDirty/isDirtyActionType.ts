import { ISetIsDirtyPageAction  } from "./model";

type RouteType = ISetIsDirtyPageAction;

export default RouteType;
