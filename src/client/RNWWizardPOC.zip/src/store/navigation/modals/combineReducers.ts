import { combineReducers } from "redux";
import { openModal } from "./reducer";

export default combineReducers({
  openModal
});
