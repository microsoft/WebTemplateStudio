
import WizardContentActionType from "../templatesActionType";
import { IOption } from "../../../types/option";
import { TEMPLATES_TYPEKEYS } from "../templateTypeKeys";

const feaRNWOptions = (
  state: IOption[] = [],
  action: WizardContentActionType
) => {
  switch (action.type) {
    case TEMPLATES_TYPEKEYS.SET_FEA_RNW_OPTIONS_SUCCESS:
      return action.payload;
    default:
      return state;
  }
};

export default feaRNWOptions;
