import { TEMPLATES_TYPEKEYS } from "../templateTypeKeys";
import { IOption } from "../../../types/option";

export interface IDetail {
  originRoute: string;
  data: IOption;
  isIntlFormatted: boolean;
}

export interface IFeaRNWOptionsActionType {
  type: TEMPLATES_TYPEKEYS.SET_FEA_RNW_OPTIONS_SUCCESS;
  payload: IOption[];
}