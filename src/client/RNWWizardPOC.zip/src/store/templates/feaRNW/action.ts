import { IFeaRNWOptionsActionType } from "./model";
import { TEMPLATES_TYPEKEYS } from "../templateTypeKeys";
import { IOption } from "../../../types/option";

const setFeaRNWOptionsSuccessAction = (pagesOptions: IOption[]): IFeaRNWOptionsActionType => ({
  payload: pagesOptions,
  type: TEMPLATES_TYPEKEYS.SET_FEA_RNW_OPTIONS_SUCCESS,
});

export { setFeaRNWOptionsSuccessAction };
