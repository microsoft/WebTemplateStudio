import { IUpdateFrameworkActionTypeAction, IFrontendFrameworksActionTypeAction, IBackendFrameworksSuccessActionTypeAction } from "./frameworks/model";
import { IPageOptionsActionType } from "./pages/model";
import { IFeaturesActionType } from "./features/models";
import { IFeaRNWOptionsActionType } from "./feaRNW/model";

type WizardContentActionType =
  | IBackendFrameworksSuccessActionTypeAction
  | IFrontendFrameworksActionTypeAction
  | IUpdateFrameworkActionTypeAction
  | IPageOptionsActionType
  | IFeaturesActionType
  | IFeaRNWOptionsActionType;

export default WizardContentActionType;
