
import { ISelectProjectTypeAction } from "./model";

type WizardSelectionActionType =
  ISelectProjectTypeAction;

export default WizardSelectionActionType;
